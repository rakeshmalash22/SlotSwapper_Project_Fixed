Frontend: cd servicehive-frontend && npm install && npm run dev
