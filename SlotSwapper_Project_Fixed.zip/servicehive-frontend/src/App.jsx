
import React, { useState, useEffect } from "react";

const API = "http://localhost:4000/api";

function saveToken(token){ localStorage.setItem("token", token); }
function getToken(){ return localStorage.getItem("token"); }

function AuthForm({onLogin}){
  const [mode,setMode] = useState("login");
  const [email,setEmail]=useState("");
  const [password,setPassword]=useState("");
  const [name,setName]=useState("");
  async function submit(e){
    e.preventDefault();
    const url = mode==="login" ? API+"/login" : API+"/signup";
    const body = mode==="login" ? {email,password} : {email,password,name};
    const res = await fetch(url, {method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify(body)});
    const data = await res.json();
    if(data.token){ saveToken(data.token); onLogin(); }
    else alert(data.error || "Failed");
  }
  return <div>
    <h3>{mode==="login" ? "Login" : "Sign Up"}</h3>
    <form onSubmit={submit}>
      {mode==="signup" && <input placeholder="Name" value={name} onChange={e=>setName(e.target.value)} />}
      <input placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} />
      <input placeholder="Password" type="password" value={password} onChange={e=>setPassword(e.target.value)} />
      <button type="submit">{mode==="login" ? "Login" : "Sign Up"}</button>
    </form>
    <button onClick={()=>setMode(mode==="login" ? "signup" : "login")}>Switch to {mode==="login" ? "Sign Up" : "Login"}</button>
  </div>
}

function App(){
  const [authed,setAuthed]=useState(!!getToken());
  const [view,setView]=useState("dashboard");
  const [events,setEvents]=useState([]);
  const [swappables,setSwappables]=useState([]);
  const [incoming,setIncoming]=useState([]);
  const [outgoing,setOutgoing]=useState([]);
  const [title,setTitle]=useState("");
  const [startTime,setStartTime]=useState("");
  const [endTime,setEndTime]=useState("");

  useEffect(()=>{ if(authed) fetchEvents(); },[authed]);

  async function fetchEvents(){
    const res = await fetch(API+"/events", {headers:{Authorization:"Bearer "+getToken()}});
    const data = await res.json();
    setEvents(data);
    const r2 = await fetch(API+"/swappable-slots", {headers:{Authorization:"Bearer "+getToken()}});
    setSwappables(await r2.json());
    const r3 = await fetch(API+"/requests/incoming", {headers:{Authorization:"Bearer "+getToken()}});
    setIncoming(await r3.json());
    const r4 = await fetch(API+"/requests/outgoing", {headers:{Authorization:"Bearer "+getToken()}});
    setOutgoing(await r4.json());
  }

  async function createEvent(e){
    e.preventDefault();
    await fetch(API+"/events", {method:"POST", headers:{"Content-Type":"application/json", Authorization:"Bearer "+getToken()}, body:JSON.stringify({title, startTime, endTime, status:"BUSY"})});
    setTitle(""); setStartTime(""); setEndTime("");
    fetchEvents();
  }

  async function makeSwappable(id){
    await fetch(API+"/events/"+id, {method:"PUT", headers:{"Content-Type":"application/json", Authorization:"Bearer "+getToken()}, body:JSON.stringify({status:"SWAPPABLE"})});
    fetchEvents();
  }

  async function requestSwap(theirSlotId){
    const mySwappables = events.filter(e=>e.status==="SWAPPABLE");
    if(mySwappables.length===0){ alert("No swappable slots of your own. Mark one as swappable first."); return; }
    const mySlotId = mySwappables[0].id;
    const res = await fetch(API+"/swap-request", {method:"POST", headers:{"Content-Type":"application/json", Authorization:"Bearer "+getToken()}, body:JSON.stringify({mySlotId,theirSlotId})});
    const data = await res.json();
    if(data.error) alert(data.error); else fetchEvents();
  }

  async function respond(requestId, accept){
    await fetch(API+"/swap-response/"+requestId, {method:"POST", headers:{"Content-Type":"application/json", Authorization:"Bearer "+getToken()}, body:JSON.stringify({accept})});
    fetchEvents();
  }

  if(!authed) return <AuthForm onLogin={()=>{setAuthed(true); fetchEvents();}} />;

  return <div style={{padding:20}}>
    <h2>SlotSwapper</h2>
    <div>
      <button onClick={()=>setView("dashboard")}>Dashboard</button>
      <button onClick={()=>setView("marketplace")}>Marketplace</button>
      <button onClick={()=>setView("requests")}>Requests</button>
      <button onClick={()=>{ localStorage.removeItem("token"); setAuthed(false); }}>Logout</button>
    </div>

    {view==="dashboard" && <div>
      <h3>Your Events</h3>
      <form onSubmit={createEvent}>
        <input placeholder="Title" value={title} onChange={e=>setTitle(e.target.value)} />
        <input placeholder="Start (ISO)" value={startTime} onChange={e=>setStartTime(e.target.value)} />
        <input placeholder="End (ISO)" value={endTime} onChange={e=>setEndTime(e.target.value)} />
        <button type="submit">Create Event</button>
      </form>
      <ul>
        {events.map(ev=> <li key={ev.id}>{ev.title} | {ev.startTime} - {ev.endTime} | {ev.status} {ev.status==="BUSY" && <button onClick={()=>makeSwappable(ev.id)}>Make Swappable</button>}</li>)}
      </ul>
    </div>}

    {view==="marketplace" && <div>
      <h3>Available Swappable Slots</h3>
      <ul>
        {swappables.map(s=> <li key={s.id}>{s.title} ({s.startTime} - {s.endTime}) <button onClick={()=>requestSwap(s.id)}>Request Swap</button></li>)}
      </ul>
    </div>}

    {view==="requests" && <div>
      <h3>Incoming Requests</h3>
      <ul>
        {incoming.map(r=> <li key={r.id}>From: {r.fromUserId} MySlot: {r.theirSlotId} <button onClick={()=>respond(r.id,true)}>Accept</button> <button onClick={()=>respond(r.id,false)}>Reject</button></li>)}
      </ul>
      <h3>Outgoing Requests</h3>
      <ul>
        {outgoing.map(r=> <li key={r.id}>To: {r.toUserId} Status: {r.status}</li>)}
      </ul>
    </div>}
  </div>;
}

export default App;
