# SlotSwapper - Fixed Full Project

This is a fixed, ready-to-run version of SlotSwapper (backend uses simple JSON DB, frontend is Vite+React).

Run backend:
cd servicehive-backend
npm install
npm start

Run frontend:
cd servicehive-frontend
npm install
npm run dev