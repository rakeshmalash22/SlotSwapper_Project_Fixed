// SlotSwapper backend - simple JSON file DB (no lowdb)
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const { v4: uuidv4 } = require('uuid');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

const app = express();
app.use(cors());
app.use(bodyParser.json());

const SECRET = process.env.JWT_SECRET || 'verysecretkey';
const DBFILE = path.join(__dirname, 'db.json');

function readDB(){
  try{
    const raw = fs.readFileSync(DBFILE, 'utf-8');
    return JSON.parse(raw);
  }catch(e){
    return { users: [], events: [], swapRequests: [] };
  }
}
function writeDB(data){
  fs.writeFileSync(DBFILE, JSON.stringify(data, null, 2));
}

// ensure db file exists with defaults
const initial = { users: [], events: [], swapRequests: [] };
if(!fs.existsSync(DBFILE)){
  writeDB(initial);
}

// auth middleware
function authMiddleware(req,res,next){
  const auth = req.headers.authorization;
  if(!auth) return res.status(401).json({ error: 'No token' });
  const parts = auth.split(' ');
  if(parts.length !== 2) return res.status(401).json({ error: 'Invalid auth header' });
  const token = parts[1];
  try{
    const decoded = jwt.verify(token, SECRET);
    req.user = decoded;
    next();
  }catch(e){
    return res.status(401).json({ error: 'Invalid token' });
  }
}

// signup
app.post('/api/signup', async (req,res)=>{
  const { name, email, password } = req.body;
  const db = readDB();
  if(db.users.find(u=>u.email===email)) return res.status(400).json({ error: 'Email exists' });
  const hash = await bcrypt.hash(password, 10);
  const user = { id: uuidv4(), name, email, password: hash };
  db.users.push(user);
  writeDB(db);
  const token = jwt.sign({ id: user.id, email: user.email, name: user.name }, SECRET);
  res.json({ token, user: { id: user.id, name: user.name, email: user.email }});
});

// login
app.post('/api/login', async (req,res)=>{
  const { email, password } = req.body;
  const db = readDB();
  const user = db.users.find(u=>u.email===email);
  if(!user) return res.status(400).json({ error: 'Invalid creds' });
  const ok = await bcrypt.compare(password, user.password);
  if(!ok) return res.status(400).json({ error: 'Invalid creds' });
  const token = jwt.sign({ id: user.id, email: user.email, name: user.name }, SECRET);
  res.json({ token, user: { id: user.id, name: user.name, email: user.email }});
});

// events CRUD
app.get('/api/events', authMiddleware, (req,res)=>{
  const db = readDB();
  const events = db.events.filter(e=>e.ownerId===req.user.id);
  res.json(events);
});

app.post('/api/events', authMiddleware, (req,res)=>{
  const { title, startTime, endTime, status } = req.body;
  const db = readDB();
  const ev = { id: uuidv4(), title, startTime, endTime, status: status||'BUSY', ownerId: req.user.id };
  db.events.push(ev);
  writeDB(db);
  res.json(ev);
});

app.put('/api/events/:id', authMiddleware, (req,res)=>{
  const id = req.params.id;
  const db = readDB();
  const ev = db.events.find(e=>e.id===id && e.ownerId===req.user.id);
  if(!ev) return res.status(404).json({ error: 'Not found' });
  Object.assign(ev, req.body);
  writeDB(db);
  res.json(ev);
});

app.delete('/api/events/:id', authMiddleware, (req,res)=>{
  const id = req.params.id;
  const db = readDB();
  const idx = db.events.findIndex(e=>e.id===id && e.ownerId===req.user.id);
  if(idx===-1) return res.status(404).json({ error: 'Not found' });
  db.events.splice(idx,1);
  writeDB(db);
  res.json({ ok: true });
});

// swappable slots (others)
app.get('/api/swappable-slots', authMiddleware, (req,res)=>{
  const db = readDB();
  const slots = db.events.filter(e => e.status === 'SWAPPABLE' && e.ownerId !== req.user.id);
  res.json(slots);
});

// create swap request
app.post('/api/swap-request', authMiddleware, (req,res)=>{
  const { mySlotId, theirSlotId } = req.body;
  const db = readDB();
  const mySlot = db.events.find(e=>e.id===mySlotId && e.ownerId===req.user.id);
  const theirSlot = db.events.find(e=>e.id===theirSlotId && e.ownerId!==req.user.id);
  if(!mySlot || !theirSlot) return res.status(400).json({ error: 'Slots invalid' });
  if(mySlot.status!=='SWAPPABLE' || theirSlot.status!=='SWAPPABLE') return res.status(400).json({ error: 'Slots not swappable' });
  mySlot.status = 'SWAP_PENDING';
  theirSlot.status = 'SWAP_PENDING';
  const request = { id: uuidv4(), fromUserId: req.user.id, toUserId: theirSlot.ownerId, mySlotId, theirSlotId, status: 'PENDING', createdAt: Date.now() };
  db.swapRequests.push(request);
  writeDB(db);
  res.json(request);
});

// respond to swap
app.post('/api/swap-response/:requestId', authMiddleware, (req,res)=>{
  const requestId = req.params.requestId;
  const { accept } = req.body;
  const db = readDB();
  const reqRec = db.swapRequests.find(r=>r.id===requestId);
  if(!reqRec) return res.status(404).json({ error: 'Request not found' });
  if(reqRec.toUserId !== req.user.id) return res.status(403).json({ error: 'Not authorized' });
  if(reqRec.status !== 'PENDING') return res.status(400).json({ error: 'Already handled' });
  const mySlot = db.events.find(e=>e.id===reqRec.mySlotId);
  const theirSlot = db.events.find(e=>e.id===reqRec.theirSlotId);
  if(!mySlot || !theirSlot) return res.status(400).json({ error: 'Slots missing' });
  if(!accept){
    reqRec.status = 'REJECTED';
    mySlot.status = 'SWAPPABLE';
    theirSlot.status = 'SWAPPABLE';
    writeDB(db);
    return res.json({ ok:true, status: 'REJECTED' });
  }
  // accept -> swap owners
  reqRec.status = 'ACCEPTED';
  const ownerA = mySlot.ownerId;
  const ownerB = theirSlot.ownerId;
  mySlot.ownerId = ownerB;
  theirSlot.ownerId = ownerA;
  mySlot.status = 'BUSY';
  theirSlot.status = 'BUSY';
  writeDB(db);
  res.json({ ok:true, status: 'ACCEPTED' });
});

// incoming/outgoing requests
app.get('/api/requests/incoming', authMiddleware, (req,res)=>{
  const db = readDB();
  const incoming = db.swapRequests.filter(r=>r.toUserId===req.user.id);
  res.json(incoming);
});
app.get('/api/requests/outgoing', authMiddleware, (req,res)=>{
  const db = readDB();
  const outgoing = db.swapRequests.filter(r=>r.fromUserId===req.user.id);
  res.json(outgoing);
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, ()=>console.log('Backend running on', PORT));