# ServiceHive SlotSwapper - Backend (Fixed)

This backend uses a simple JSON file as a database (db.json). No lowdb to avoid compatibility issues.

## Setup
1. cd servicehive-backend
2. npm install
3. npm start

API runs at http://localhost:4000